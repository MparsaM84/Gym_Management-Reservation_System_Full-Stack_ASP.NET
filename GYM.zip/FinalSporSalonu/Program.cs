﻿
using FinalSporSalonu.DataDBC;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// MVC
builder.Services.AddControllersWithViews();

// EF Core + SQL Server (Retry On Failure dahil)
builder.Services.AddDbContext<SporSalonFinalDb>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("SporSalonDb")));

var app = builder.Build();

// Hata sayfası / güvenlik
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();

// wwwroot (uploads dahil) çalışsın
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();
app.MapGet("/dbtest", async (FinalSporSalonu.DataDBC.SporSalonFinalDb db) =>
{
    try
    {
        var can = await db.Database.CanConnectAsync();
        return Results.Ok("DB CanConnect: " + can);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.ToString());
    }
});
// Default route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();