﻿using Microsoft.EntityFrameworkCore;
using FinalSporSalonu.Models;
using System.Collections.Generic;

namespace SporSalonWeb.Data
{
    public class SporSalonFinalDb : DbContext
    {
        public SporSalonFinalDb(DbContextOptions<SporSalonFinalDb> options) : base(options)
        {
        }

        public DbSet<UyelikPaketi> UyelikPaketleri { get; set; }
        public DbSet<Uye> Uyeler { get; set; }
        public DbSet<Ders> Dersler { get; set; }
        public DbSet<Katilim> Katilimlar { get; set; }
    }
}