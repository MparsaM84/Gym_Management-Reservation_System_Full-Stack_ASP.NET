﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FinalSporSalonu.Models
{
    public class Katilim
    {
        [Key]
        public int KatilimId { get; set; }

        [ForeignKey(nameof(Uye))]
        public int UyeId { get; set; }

        [ForeignKey(nameof(Ders))]
        public int DersId { get; set; }

        public DateTime KayitTarihi { get; set; } = DateTime.Now;

        // Navigation
        public Uye? Uye { get; set; }
        public Ders? Ders { get; set; }
    }
}