﻿using System.ComponentModel.DataAnnotations;

namespace FinalSporSalonu.Models
{
    public class UyelikPaketi
    {
        [Key]
        public int UyelikPaketiId { get; set; }

        [Required, StringLength(80)]
        public string PaketAdi { get; set; } = null!;

        [Range(1, 3650)]
        public int SureGun { get; set; }

        [Range(0, 1_000_000)]
        public decimal Fiyat { get; set; }

        // Resim yolu (DB'ye bu yazılır)
        public string? PaketResimYolu { get; set; }

        // Navigation
        public List<Uye> Uyeler { get; set; } = new();
    }
}