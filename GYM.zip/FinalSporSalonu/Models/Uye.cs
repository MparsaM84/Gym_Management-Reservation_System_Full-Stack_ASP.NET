﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FinalSporSalonu.Models
{
    public class Uye
    {
        [Key]
        public int UyeId { get; set; }

        [Required, StringLength(60)]
        public string Ad { get; set; } = null!;

        [Required, StringLength(60)]
        public string Soyad { get; set; } = null!;

        [Required, EmailAddress, StringLength(120)]
        public string Email { get; set; } = null!;

        [StringLength(30)]
        public string? Telefon { get; set; }

        public string? FotoYolu { get; set; }

        // FK
        [ForeignKey(nameof(UyelikPaketi))]
        public int UyelikPaketiId { get; set; }

        // Navigation
        public UyelikPaketi? UyelikPaketi { get; set; }
        public List<Katilim> Katilimlar { get; set; } = new();
    }
}