﻿using System.ComponentModel.DataAnnotations;

namespace FinalSporSalonu.Models
{
    public class Ders
    {
        [Key]
        public int DersId { get; set; }

        [Required, StringLength(80)]
        public string DersAdi { get; set; } = null!;

        [Required, StringLength(20)]
        public string Gun { get; set; } = null!;   // Pazartesi...

        [Required, StringLength(10)]
        public string Saat { get; set; } = null!;  // 18:00

        [Range(1, 500)]
        public int Kontenjan { get; set; }

        // Navigation
        public List<Katilim> Katilimlar { get; set; } = new();
    }
}