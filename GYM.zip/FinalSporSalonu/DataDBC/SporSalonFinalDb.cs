﻿using FinalSporSalonu.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalSporSalonu.DataDBC
{
    public class SporSalonFinalDb : DbContext
    {
        public SporSalonFinalDb(DbContextOptions<SporSalonFinalDb> options) : base(options) { }

        public DbSet<UyelikPaketi> UyelikPaketleri { get; set; }
        public DbSet<Uye> Uyeler { get; set; }
        public DbSet<Ders> Dersler { get; set; }
        public DbSet<Katilim> Katilimlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UyelikPaketi>().ToTable("UyelikPaketi");
            modelBuilder.Entity<Uye>().ToTable("Uye");
            modelBuilder.Entity<Ders>().ToTable("Ders");
            modelBuilder.Entity<Katilim>().ToTable("Katilim");
        }

        
    }
}