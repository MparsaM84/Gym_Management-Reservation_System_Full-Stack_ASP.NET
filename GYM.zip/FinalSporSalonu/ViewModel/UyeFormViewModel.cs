﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace FinalSporSalonu.ViewModels
{
    public class UyeFormViewModel
    {
        public int UyeId { get; set; }

        [Required, StringLength(60)]
        public string Ad { get; set; } = null!;

        [Required, StringLength(60)]
        public string Soyad { get; set; } = null!;

        [Required, EmailAddress, StringLength(120)]
        public string Email { get; set; } = null!;

        [StringLength(30)]
        public string? Telefon { get; set; }

        public int UyelikPaketiId { get; set; }

        public List<SelectListItem> Paketler { get; set; } = new();
    }
}