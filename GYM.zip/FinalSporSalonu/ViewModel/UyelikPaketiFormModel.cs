﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace FinalSporSalonu.ViewModels
{
    public class UyelikPaketiFormViewModel
    {
        public int UyelikPaketiId { get; set; }

        [Required, StringLength(80)]
        public string PaketAdi { get; set; } = null!;

        [Range(1, 3650)]
        public int SureGun { get; set; }

        [Range(0, 1_000_000)]
        public decimal Fiyat { get; set; }

        // Upload
        public IFormFile? Resim { get; set; }

        // DB'ye kaydedilen yol
        public string? PaketResimYolu { get; set; }
    }
}