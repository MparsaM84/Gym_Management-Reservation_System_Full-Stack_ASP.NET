﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace FinalSporSalonu.ViewModels
{
    public class KatilimFormViewModel
    {
        public int KatilimId { get; set; }

        [Required]
        public int UyeId { get; set; }

        [Required]
        public int DersId { get; set; }

        public List<SelectListItem> Uyeler { get; set; } = new();
        public List<SelectListItem> Dersler { get; set; } = new();
    }
}