﻿using System.ComponentModel.DataAnnotations;

namespace FinalSporSalonu.ViewModels
{
    public class DersFormViewModel
    {
        public int DersId { get; set; }

        [Required, StringLength(80)]
        public string DersAdi { get; set; } = null!;

        [Required, StringLength(20)]
        public string Gun { get; set; } = null!;

        [Required, StringLength(10)]
        public string Saat { get; set; } = null!;

        [Range(1, 500)]
        public int Kontenjan { get; set; }
    }
}