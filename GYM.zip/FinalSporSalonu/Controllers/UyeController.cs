﻿
using FinalSporSalonu.DataDBC;
using FinalSporSalonu.Models;
using FinalSporSalonu.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace FinalSporSalonu.Controllers
{
    public class UyeController : Controller
    {
        private readonly SporSalonFinalDb _context;

        public UyeController(SporSalonFinalDb context)
        {
            _context = context;
        }
     

        // GET: Uye
        public async Task<IActionResult> Index()
        {
            var uyeler = await _context.Uyeler.Include(u => u.UyelikPaketi).ToListAsync();
            return View(uyeler);
        }

        // GET: Uye/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var uye = await _context.Uyeler
                .Include(u => u.UyelikPaketi)
                .FirstOrDefaultAsync(x => x.UyeId == id);

            if (uye == null) return NotFound();
            return View(uye);
        }

        // GET: Uye/Create  (VM)
        public async Task<IActionResult> Create()
        {
            var vm = new UyeFormViewModel
            {
                Paketler = await _context.UyelikPaketleri
                    .OrderBy(p => p.PaketAdi)
                    .Select(p => new SelectListItem
                    {
                        Value = p.UyelikPaketiId.ToString(),
                        Text = p.PaketAdi
                    }).ToListAsync()
            };

            return View(vm);
        }

        // POST: Uye/Create (VM)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UyeFormViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                vm.Paketler = await _context.UyelikPaketleri
                    .OrderBy(p => p.PaketAdi)
                    .Select(p => new SelectListItem
                    {
                        Value = p.UyelikPaketiId.ToString(),
                        Text = p.PaketAdi
                    }).ToListAsync();
                return View(vm);
            }

            var uye = new Uye
            {
                Ad = vm.Ad,
                Soyad = vm.Soyad,
                Email = vm.Email,
                Telefon = vm.Telefon,
                UyelikPaketiId = vm.UyelikPaketiId
            };

            _context.Add(uye);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Uye/Edit/5 (VM)
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var uye = await _context.Uyeler.FindAsync(id);
            if (uye == null) return NotFound();

            var vm = new UyeFormViewModel
            {
                UyeId = uye.UyeId,
                Ad = uye.Ad,
                Soyad = uye.Soyad,
                Email = uye.Email,
                Telefon = uye.Telefon,
                UyelikPaketiId = uye.UyelikPaketiId,
                Paketler = await _context.UyelikPaketleri
                    .OrderBy(p => p.PaketAdi)
                    .Select(p => new SelectListItem
                    {
                        Value = p.UyelikPaketiId.ToString(),
                        Text = p.PaketAdi
                    }).ToListAsync()
            };

            return View(vm);
        }

        // POST: Uye/Edit/5 (VM)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, UyeFormViewModel vm)
        {
            if (id != vm.UyeId) return NotFound();

            if (!ModelState.IsValid)
            {
                vm.Paketler = await _context.UyelikPaketleri
                    .OrderBy(p => p.PaketAdi)
                    .Select(p => new SelectListItem
                    {
                        Value = p.UyelikPaketiId.ToString(),
                        Text = p.PaketAdi
                    }).ToListAsync();
                return View(vm);
            }

            var uye = await _context.Uyeler.FindAsync(id);
            if (uye == null) return NotFound();

            uye.Ad = vm.Ad;
            uye.Soyad = vm.Soyad;
            uye.Email = vm.Email;
            uye.Telefon = vm.Telefon;
            uye.UyelikPaketiId = vm.UyelikPaketiId;

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Uye/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var uye = await _context.Uyeler
                .Include(u => u.UyelikPaketi)
                .FirstOrDefaultAsync(x => x.UyeId == id);

            if (uye == null) return NotFound();
            return View(uye);
        }

        // POST: Uye/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var uye = await _context.Uyeler.FindAsync(id);
            if (uye != null)
            {
                _context.Uyeler.Remove(uye);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}