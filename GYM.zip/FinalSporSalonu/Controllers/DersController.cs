﻿
using FinalSporSalonu.DataDBC;
using FinalSporSalonu.Models;
using FinalSporSalonu.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinalSporSalonu.Controllers
{
    public class DersController : Controller
    {
        private readonly SporSalonFinalDb _context;

        public DersController(SporSalonFinalDb context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Dersler.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            var ders = await _context.Dersler.FirstOrDefaultAsync(x => x.DersId == id);
            if (ders == null) return NotFound();
            return View(ders);
        }

        // VM Create
        public IActionResult Create()
        {
            return View(new DersFormViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DersFormViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var ders = new Ders
            {
                DersAdi = vm.DersAdi,
                Gun = vm.Gun,
                Saat = vm.Saat,
                Kontenjan = vm.Kontenjan
            };

            _context.Add(ders);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // VM Edit
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var ders = await _context.Dersler.FindAsync(id);
            if (ders == null) return NotFound();

            var vm = new DersFormViewModel
            {
                DersId = ders.DersId,
                DersAdi = ders.DersAdi,
                Gun = ders.Gun,
                Saat = ders.Saat,
                Kontenjan = ders.Kontenjan
            };

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, DersFormViewModel vm)
        {
            if (id != vm.DersId) return NotFound();
            if (!ModelState.IsValid) return View(vm);

            var ders = await _context.Dersler.FindAsync(id);
            if (ders == null) return NotFound();

            ders.DersAdi = vm.DersAdi;
            ders.Gun = vm.Gun;
            ders.Saat = vm.Saat;
            ders.Kontenjan = vm.Kontenjan;

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var ders = await _context.Dersler.FirstOrDefaultAsync(x => x.DersId == id);
            if (ders == null) return NotFound();
            return View(ders);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ders = await _context.Dersler.FindAsync(id);
            if (ders != null)
            {
                _context.Dersler.Remove(ders);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}