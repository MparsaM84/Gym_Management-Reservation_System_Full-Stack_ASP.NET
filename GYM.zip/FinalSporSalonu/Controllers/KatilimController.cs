﻿using FinalSporSalonu.DataDBC;
using FinalSporSalonu.Models;
using FinalSporSalonu.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace FinalSporSalonu.Controllers
{
    public class KatilimController : Controller
    {
        private readonly SporSalonFinalDb _context;
        public KatilimController(SporSalonFinalDb context) => _context = context;

        public async Task<IActionResult> Index()
        {
            var list = await _context.Katilimlar
                .Include(k => k.Uye)
                .Include(k => k.Ders)
                .ToListAsync();
            return View(list);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var kayit = await _context.Katilimlar
                .Include(k => k.Uye)
                .Include(k => k.Ders)
                .FirstOrDefaultAsync(x => x.KatilimId == id);

            if (kayit == null) return NotFound();
            return View(kayit);
        }

        // GET: Katilim/Create
        public async Task<IActionResult> Create()
        {
            var vm = new KatilimFormViewModel
            {
                Uyeler = await _context.Uyeler
                    .OrderBy(u => u.Email)
                    .Select(u => new SelectListItem { Value = u.UyeId.ToString(), Text = u.Email })
                    .ToListAsync(),

                Dersler = await _context.Dersler
                    .OrderBy(d => d.DersAdi)
                    .Select(d => new SelectListItem { Value = d.DersId.ToString(), Text = d.DersAdi })
                    .ToListAsync()
            };

            return View(vm);
        }

        // POST: Katilim/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(KatilimFormViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                vm.Uyeler = await _context.Uyeler
                    .OrderBy(u => u.Email)
                    .Select(u => new SelectListItem { Value = u.UyeId.ToString(), Text = u.Email })
                    .ToListAsync();

                vm.Dersler = await _context.Dersler
                    .OrderBy(d => d.DersAdi)
                    .Select(d => new SelectListItem { Value = d.DersId.ToString(), Text = d.DersAdi })
                    .ToListAsync();

                return View(vm);
            }

            var katilim = new Katilim
            {
                UyeId = vm.UyeId,
                DersId = vm.DersId,
                KayitTarihi = DateTime.Now
            };

            _context.Katilimlar.Add(katilim);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: Katilim/Edit/1
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var kayit = await _context.Katilimlar.FindAsync(id);
            if (kayit == null) return NotFound();

            var vm = new KatilimFormViewModel
            {
                KatilimId = kayit.KatilimId,
                UyeId = kayit.UyeId,
                DersId = kayit.DersId,
                Uyeler = await _context.Uyeler
                    .OrderBy(u => u.Email)
                    .Select(u => new SelectListItem { Value = u.UyeId.ToString(), Text = u.Email })
                    .ToListAsync(),
                Dersler = await _context.Dersler
                    .OrderBy(d => d.DersAdi)
                    .Select(d => new SelectListItem { Value = d.DersId.ToString(), Text = d.DersAdi })
                    .ToListAsync()
            };

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, KatilimFormViewModel vm)
        {
            if (id != vm.KatilimId) return NotFound();

            if (!ModelState.IsValid)
            {
                vm.Uyeler = await _context.Uyeler
                    .OrderBy(u => u.Email)
                    .Select(u => new SelectListItem { Value = u.UyeId.ToString(), Text = u.Email })
                    .ToListAsync();

                vm.Dersler = await _context.Dersler
                    .OrderBy(d => d.DersAdi)
                    .Select(d => new SelectListItem { Value = d.DersId.ToString(), Text = d.DersAdi })
                    .ToListAsync();

                return View(vm);
            }

            var kayit = await _context.Katilimlar.FindAsync(id);
            if (kayit == null) return NotFound();

            kayit.UyeId = vm.UyeId;
            kayit.DersId = vm.DersId;

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Katilim/Delete/1
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var kayit = await _context.Katilimlar
                .Include(k => k.Uye)
                .Include(k => k.Ders)
                .FirstOrDefaultAsync(x => x.KatilimId == id);

            if (kayit == null) return NotFound();
            return View(kayit);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var kayit = await _context.Katilimlar.FindAsync(id);
            if (kayit != null)
            {
                _context.Katilimlar.Remove(kayit);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
