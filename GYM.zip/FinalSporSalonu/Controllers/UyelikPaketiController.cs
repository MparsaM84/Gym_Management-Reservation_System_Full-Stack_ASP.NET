﻿
using FinalSporSalonu.DataDBC;
using FinalSporSalonu.Models;
using FinalSporSalonu.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinalSporSalonu.Controllers
{
    public class UyelikPaketiController : Controller
    {
        private readonly SporSalonFinalDb _context;

        public UyelikPaketiController(SporSalonFinalDb context)
        {
            _context = context;
        }

        // GET: UyelikPaketi
        public async Task<IActionResult> Index()
        {
            return View(await _context.UyelikPaketleri.ToListAsync());
        }

        // GET: UyelikPaketi/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var paket = await _context.UyelikPaketleri.FirstOrDefaultAsync(x => x.UyelikPaketiId == id);
            if (paket == null) return NotFound();

            return View(paket);
        }

        // GET: UyelikPaketi/Create
        public IActionResult Create()
        {
            return View(new UyelikPaketiFormViewModel());
        }

        // POST: UyelikPaketi/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UyelikPaketiFormViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            string? resimYolu = null;

            if (vm.Resim != null)
            {
                var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                Directory.CreateDirectory(uploadsFolder);

                var fileName = Guid.NewGuid() + Path.GetExtension(vm.Resim.FileName);
                var filePath = Path.Combine(uploadsFolder, fileName);

                using var stream = new FileStream(filePath, FileMode.Create);
                await vm.Resim.CopyToAsync(stream);

                resimYolu = "/uploads/" + fileName;
            }

            var paket = new UyelikPaketi
            {
                PaketAdi = vm.PaketAdi,
                SureGun = vm.SureGun,
                Fiyat = vm.Fiyat,
                PaketResimYolu = resimYolu
            };

            _context.Add(paket);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: UyelikPaketi/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var paket = await _context.UyelikPaketleri.FindAsync(id);
            if (paket == null) return NotFound();

            var vm = new UyelikPaketiFormViewModel
            {
                UyelikPaketiId = paket.UyelikPaketiId,
                PaketAdi = paket.PaketAdi,
                SureGun = paket.SureGun,
                Fiyat = paket.Fiyat,
                PaketResimYolu = paket.PaketResimYolu
            };

            return View(vm);
        }

        // POST: UyelikPaketi/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, UyelikPaketiFormViewModel vm)
        {
            if (id != vm.UyelikPaketiId) return NotFound();
            if (!ModelState.IsValid) return View(vm);

            var paket = await _context.UyelikPaketleri.FindAsync(id);
            if (paket == null) return NotFound();

            // Eğer yeni resim seçildiyse upload et, yoksa eskisi kalsın
            if (vm.Resim != null)
            {
                var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                Directory.CreateDirectory(uploadsFolder);

                var fileName = Guid.NewGuid() + Path.GetExtension(vm.Resim.FileName);
                var filePath = Path.Combine(uploadsFolder, fileName);

                using var stream = new FileStream(filePath, FileMode.Create);
                await vm.Resim.CopyToAsync(stream);

                paket.PaketResimYolu = "/uploads/" + fileName;
            }

            paket.PaketAdi = vm.PaketAdi;
            paket.SureGun = vm.SureGun;
            paket.Fiyat = vm.Fiyat;

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: UyelikPaketi/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var paket = await _context.UyelikPaketleri.FirstOrDefaultAsync(x => x.UyelikPaketiId == id);
            if (paket == null) return NotFound();

            return View(paket);
        }

        // POST: UyelikPaketi/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var paket = await _context.UyelikPaketleri.FindAsync(id);
            if (paket != null)
            {
                _context.UyelikPaketleri.Remove(paket);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}